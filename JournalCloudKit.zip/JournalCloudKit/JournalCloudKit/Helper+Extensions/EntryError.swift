//
//  EntryError.swift
//  JournalCloudKit
//
//  Created by Lon Chandler Madsen on 8/9/21.
//

import Foundation

enum EntryError: LocalizedError {
    
    case ckError(Error)
    case couldNotUnwrap
    
    var errorDescription: String? {
        switch self {
        case .ckError(let error):
            return error.localizedDescription
        case .couldNotUnwrap:
            return "Unable to unwrap this Entry."
        }
    }
}//end of enum
