//
//  Entry.swift
//  JournalCloudKit
//
//  Created by Lon Chandler Madsen on 8/9/21.
//

import Foundation
import CloudKit

struct EntryConstants{
    static let recordTypeKey = "Entry"
    static let TitleKey = "title"
    static let BodyKey = "body"
    static let TimestampKey = "timestamp"
}//end of struct


class Entry {
    var title: String
    var body: String
    var timestamp: Date
    
    init(title: String, body: String, timestamp: Date = Date()) {
        self.title = title
        self.body = body
        self.timestamp = timestamp
    }
}//end of class

//CKRecord -> Entry
extension Entry {
    
    convenience init?(ckRecord: CKRecord) {
        guard let title = ckRecord[EntryConstants.TitleKey] as? String,
              let body = ckRecord[EntryConstants.BodyKey] as? String,
              let timestamp = ckRecord[EntryConstants.TimestampKey] as? Date else { return nil }
        
        self.init(title: title, body: body, timestamp: timestamp)
    }
}//end of extension

//Entry -> CKRecord
extension CKRecord {
    convenience init(entry: Entry) {
        self.init (recordType: EntryConstants.recordTypeKey)
        
        self.setValuesForKeys([
            EntryConstants.TitleKey : entry.title,
            EntryConstants.BodyKey : entry.body,
            EntryConstants.TimestampKey : entry.timestamp
        ])
    }
}//end of extension
